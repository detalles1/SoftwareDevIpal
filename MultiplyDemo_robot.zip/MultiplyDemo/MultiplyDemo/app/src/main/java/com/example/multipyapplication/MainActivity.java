package com.example.multipyapplication;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.robot.motion.RobotMotion;
import android.robot.speech.SpeechManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends Activity {

    private SpeechManager mSpeechManager;
    private RobotMotion mRobotMotion = new RobotMotion();
    private Handler handler = new Handler();
    private Random random = new Random();
    private int correctAnswer;
    private int retryCount = 0;
    private static final int MAX_RETRIES = 10;
    private boolean alefInitialized = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Check permissions for Android 6.0+
        checkPermissions();

        // Initialize Alef System
        initializeAlef();

        // Set up UI buttons
        setupButtons();

        // Start random blinking
        startRandomBlinking();
    }

    private void checkPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO}, 1);
            }
        }
    }

    private void initializeAlef() {
        Log.d("MainActivity", "Initializing Alef System...");
        alefInitialized = true; // Replace this with the actual Alef initialization logic if required
        if (alefInitialized) {
            Log.d("MainActivity", "Alef initialized successfully.");
            initializeSpeechManager();
        } else {
            Log.e("MainActivity", "Alef initialization failed.");
            retryAlefInitialization();
        }
    }

    private void retryAlefInitialization() {
        if (retryCount >= MAX_RETRIES) {
            triggerRobotPrompt("Unable to initialize Alef system. Please restart the robot.");
            return;
        }

        retryCount++;
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Log.d("MainActivity", "Retrying Alef initialization (attempt " + retryCount + ")");
                initializeAlef();
            }
        }, 5000);
    }

    private void initializeSpeechManager() {
        Log.d("MainActivity", "Initializing SpeechManager...");
        mSpeechManager = (SpeechManager) getSystemService("speech");
        if (mSpeechManager == null) {
            mSpeechManager = new SpeechManager(this, new SpeechManager.OnConnectListener() {
                @Override
                public void onConnect(boolean status) {
                    if (status) {
                        Log.d("MainActivity", "SpeechManager initialized successfully!");
                        mSpeechManager.setTtsEnable(true); // Enable TTS
                        initializeTtsListener();
                        triggerInitialPrompt();
                    } else {
                        Log.e("MainActivity", "SpeechManager initialization failed.");
                        triggerRobotPrompt("System is syncing. Please wait...");
                        retrySpeechManagerInitialization();
                    }
                }
            }, "com.avatar.dialog");
        } else {
            initializeTtsListener();
            triggerInitialPrompt();
        }
    }

    private void retrySpeechManagerInitialization() {
        if (retryCount >= MAX_RETRIES) {
            triggerRobotPrompt("Unable to initialize SpeechManager. Please restart the robot.");
            return;
        }

        retryCount++;
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Log.d("MainActivity", "Retrying SpeechManager initialization (attempt " + retryCount + ")");
                initializeSpeechManager();
            }
        }, 5000);
    }

    private void setupButtons() {
        // Test Listen button
        Button testListenButton = (Button) findViewById(R.id.btn_test_listen);
        testListenButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startMultiplicationGame();
            }
        });

        // Exit button
        Button exitButton = (Button) findViewById(R.id.btn_exit);
        exitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Reset button
        Button resetButton = (Button) findViewById(R.id.btn_reset);
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                triggerRobotPrompt("Let's practice multiplication. Please select a number.");
            }
        });

        // Number buttons (1-10)
        for (int i = 1; i <= 10; i++) {
            int resID = getResources().getIdentifier("button" + i, "id", getPackageName());
            Button numberButton = (Button) findViewById(resID);
            final int selectedNumber = i;
            if (numberButton != null) {
                numberButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        openModeSelectionActivity(selectedNumber);
                    }
                });
            } else {
                Log.e("MainActivity", "Button with ID button" + i + " not found.");
            }
        }
    }

    private void openModeSelectionActivity(int number) {
        Intent intent = new Intent(MainActivity.this, ModeSelectionActivity.class);
        intent.putExtra("number", number); // Pass the selected number
        startActivity(intent);
    }

    private void initializeTtsListener() {
        if (mSpeechManager != null) {
            mSpeechManager.setTtsListener(new SpeechManager.TtsListener() {
                @Override
                public void onBegin(int requestId) {
                    Log.d("MainActivity", "TTS started: requestId = " + requestId);
                }

                @Override
                public void onEnd(int requestId) {
                    Log.d("MainActivity", "TTS finished: requestId = " + requestId);
                }

                @Override
                public void onError(int requestId) {
                    Log.e("MainActivity", "TTS error: requestId = " + requestId);
                }
            });
        }
    }

    private void triggerInitialPrompt() {
        triggerRobotPrompt("Let's practice multiplication. Please select a number.");
    }

    private void triggerRobotPrompt(String phrase) {
        if (mSpeechManager != null && mSpeechManager.isEstablished() && mSpeechManager.getTtsEnable()) {
            mSpeechManager.forceStartSpeaking(phrase, false, false);
            Log.d("MainActivity", "Robot is speaking: " + phrase);
        } else {
            Log.e("MainActivity", "Cannot start TTS: SpeechManager is not initialized or TTS is disabled.");
        }
    }

    private void startRandomBlinking() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (mRobotMotion != null) {
                    mRobotMotion.emoji(RobotMotion.Emoji.BLINK);
                }
                int delay = 2000 + random.nextInt(8000);
                handler.postDelayed(this, delay);
            }
        });
    }

    private void startMultiplicationGame() {
        int num1 = random.nextInt(10) + 1;
        int num2 = random.nextInt(10) + 1;
        correctAnswer = num1 * num2;

        String question = "What is " + num1 + " times " + num2 + "?";
        if (mSpeechManager != null) {
            mSpeechManager.forceStartSpeaking(question, false, false);
        } else {
            Log.e("MainActivity", "SpeechManager is not initialized. Cannot speak.");
        }
    }
}
