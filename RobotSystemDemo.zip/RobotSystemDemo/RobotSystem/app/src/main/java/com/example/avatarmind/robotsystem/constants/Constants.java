package com.example.avatarmind.robotsystem.constants;

public class Constants {

    public static final int ENVIRONMENT_SAFETY_STATUS = 1;

    public static final int TOUCH_EVENT = 2;

    public static final int SENSOR_EVENT = 3;

}
